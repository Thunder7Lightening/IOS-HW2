//
//  ViewController.swift
//  CardGame
//
//  Created by student on 2018/3/12.
//  Copyright © 2018年 106598047. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var shouldSetEmoji:Bool = true
    var shouldSetShuffle:Bool = true
    
    lazy var game = Concentration(numberOfPairsCards: 3/*numberOfPairsOfCardsOnTable*/)
    
//    var numberOfPairsOfCardsOnTable:Int{
//        return (cardButtons.count + 1) / 2
//    }
    
    var flipCount = 0{
        didSet{
            flipLabel.text = "Flip: \(flipCount)"
        }
    }
    
    @IBOutlet weak var flipLabel: UILabel!
    @IBOutlet var cardButtons: [UIButton]!
    
    var emojiChoices: Array<String> = ["🏈","🏀","🏌","🏇","🎫","🎻","😚","🍧","🍼"]
    var emojiDict = [Int: String]()
    
    @IBAction func startOverTheGame(_ sender: UIButton) {
        startTheGame()
    }
    
    func startTheGame() {
        resetGameData()
        updateViewAfterReset()
    }
    
    func resetGameData()
    {
        flipCount = 0
        resetCardsData()
    }
    
    func resetCardsData()
    {
        shouldSetShuffle = true
        for index in game.cards.indices
        {
            game.cards[index].isFaceUp = false
            game.cards[index].isMathched = false
        }
    }
    
    func updateViewAfterReset()
    {
        for index in cardButtons.indices
        {
            let button = cardButtons[index]
            let card = game.cards[index]
            
            if !card.isFaceUp
            {
                button.setTitle("", for: UIControlState.normal)
                button.backgroundColor = #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1)
            }
        }
    }
    
    @IBAction func touchCard(_ sender: UIButton) {
        setEmojiDict(shouldSet: shouldSetEmoji)
        startToShuffleCards(shouldShuffleCards: shouldSetShuffle)
        
        if let cardNumber = cardButtons.index(of: sender)
        {
            game.chooseCard(at: cardNumber)
            updateViewFromModel(at: cardNumber)
        }
        else
        {
            print("error")
        }
    }
    
    func startToShuffleCards(shouldShuffleCards:Bool)
    {
        if shouldShuffleCards
        {
            game.shuffleCards()
            shouldSetShuffle = false
        }
    }
    
    func setEmojiDict(shouldSet:Bool)
    {
        if shouldSet
        {
            for index in game.cards.indices
            {
                setEmoji(for: game.cards[index])
            }
            shouldSetEmoji = false
        }
        
    }
    
    func setEmoji(for card:Card)
    {
        if emojiDict[card.identifier] == nil, emojiChoices.count > 0
        {
            let randomIndex = Int(arc4random_uniform(UInt32(emojiChoices.count)))
            emojiDict[card.identifier] = emojiChoices.remove(at: randomIndex)
        }
    }
    
    func getEmoji(for card:Card) ->String
    {
        return emojiDict[card.identifier] ?? "x"
    }
    
    func updateViewFromModel(at index: Int)
    {
        
        for index in cardButtons.indices
        {
            let button = cardButtons[index]
            let card = game.cards[index]
            
            if card.isFaceUp
            {
                button.setTitle(getEmoji(for: card), for: UIControlState.normal)
                button.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
            }
            else
            {
                let matchedCardFaceUpEmoji:String = card.isMathched ? getEmoji(for: card) : ""
                button.setTitle(matchedCardFaceUpEmoji, for: UIControlState.normal)
                button.backgroundColor = card.isMathched ? #colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1) : #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1)
            }
        }
        
        if game.cards[index].isMathched == false
        {
            flipCount += 1
        }
    }
    
    func isACardMatched() ->Bool
    {
        for index in cardButtons.indices
        {
            let card = game.cards[index]
            
            if card.isMathched
            {
                return true
            }
        }
        return false
    }
    
    func flipCard(withEmoji emoji:String, on button:UIButton)
    {
        if button.currentTitle == emoji
        {
            button.setTitle("", for: UIControlState.normal)
            button.backgroundColor = #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1)
        }
        else
        {
            button.setTitle(emoji, for: UIControlState.normal)
            button.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }
    }

}

