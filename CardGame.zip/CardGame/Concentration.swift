//
//  Concentration.swift
//  CardGame
//
//  Created by student on 2018/3/12.
//  Copyright © 2018年 106598047. All rights reserved.
//

import Foundation

class Concentration {
    //var cards = Array<Card>
    //var cards = Array<Card>()
    var cards = [Card]()
    
    var numberOfPairsCards:Int
    
    init(numberOfPairsCards: Int)
    {
        self.numberOfPairsCards = numberOfPairsCards
        for _ in 1...numberOfPairsCards {
            let card = Card()
            //cards.append(card)
            //cards.append(card)
            cards += [card, card]
        }
    }
    
    // store index of card which is faced up(only one card is faced up)
    // 儲存場面上只有一張face up的卡片的index
    var indexOfOneAndOnlyOneFaceUpCard:Int?{
        get{
            var foundIndex: Int?
            for index in cards.indices{
                if cards[index].isFaceUp{
                    if foundIndex == nil{
                        foundIndex = index
                    }
                    else
                    {
                        return nil
                    }
                }
            }
            return foundIndex
        }
        set{
            for index in cards.indices{
                cards[index].isFaceUp = (index == newValue)
            }
        }
    }
    
    func shuffleCards()
    {
        for index in cards.indices
        {
            let randomIndex = Int(arc4random_uniform(UInt32(cards.count)))
            swapTwoCards(cardIndex: index, anotherCardIndex: randomIndex)
        }
    }
    
    func swapTwoCards(cardIndex:Int, anotherCardIndex:Int)
    {
        let tmpCard:Card = cards[cardIndex]
        cards[cardIndex] = cards[anotherCardIndex]
        cards[anotherCardIndex] = tmpCard
    }
    
    func chooseCard(at index: Int)
    {
//         cards[index].isFaceUp = !cards[index].isFaceUp
        if !cards[index].isMathched
        {
            if let matchingIndex = indexOfOneAndOnlyOneFaceUpCard, matchingIndex != index
            {
                if cards[matchingIndex].identifier == cards[index].identifier
                {
                    cards[matchingIndex].isMathched = true
                    cards[index].isMathched = true
                }
                cards[index].isFaceUp = true
                //indexOfOneAndOnlyOneFaceUpCard = nil
            }
            else // if indexOfOneAndOnlyOneFaceUpCard is nil
            {
//                for flipDownIndex in cards.indices{
//                    cards[flipDownIndex].isFaceUp = false
//                }
//                cards[index].isFaceUp = true
                indexOfOneAndOnlyOneFaceUpCard = index
            }
        }
    }
}
